# pyicd

<b> Functionality </b>

* Query ICD-9 or ICD-10 codes for code validity, clinical description, and level of ICD hierarchy.

